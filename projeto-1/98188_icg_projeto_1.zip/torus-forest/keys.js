﻿"use strict";

const keys = {
    W: false,
    A: false,
    S: false,
    D: false
};
